
import ThimPostMessageOutput from './postmessage';

jQuery(document).ready(function () {
    ThimPostMessageOutput();
});