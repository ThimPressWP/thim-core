<?php
namespace ThimPress\Customizer\Modules\Webfonts;

// Download all fonts from Google Fonts API to local.
class Downloader {

	protected $url;

	protected $filesystem;

	protected $font_folder = 'thim-fonts';

	public function __construct( $url ) {
		$this->url = $url;
		$this->filesystem = $this->get_filesystem();
	}

	public function get_styles() {
		$styles = $this->get_content_cache();

		$fonts = $this->get_fonts_local();

		// replace src google fonts to local fonts in $styles.
		foreach ( $fonts as $font ) {
			$styles = str_replace(
				$font['src'],
				$font['url'],
				$styles
			);
		}

		return $styles;
	}

	protected function get_fonts_local() {
		$fonts = $this->download_fonts_to_local();

		// Add file url to fonts.
		$fonts = array_map(
			function( $font ) {
				$font['url'] = $this->get_font_url( $font['name'], $font['folder'] );
				return $font;
			},
			$fonts
		);

		return $fonts;
	}

	protected function get_font_url( $font_file_name, $font_family_folder ) {
		$upload_dir = wp_upload_dir();
		$fonts_dir  = $upload_dir['baseurl'] . '/' . $this->font_folder;

		return $fonts_dir . '/' . $font_family_folder . '/' . $font_file_name;
	}

	public function download_fonts_to_local() {
		$fonts = $this->get_files_from_contents();

		$stored = get_option( 'thim_customizer_downloaded_font_files', array() );
		$stored_names = array();
		$change     = false;

		if ( ! empty( $stored ) ) {
			$stored_names = array_map(
				function( $font ) {
					return $font['name'];
				},
				$stored
			);
		}

		// download fonts to folder fonts in wp_content.
		$upload_dir = wp_upload_dir();
		$fonts_dir  = $upload_dir['basedir'] . '/' . $this->font_folder;

		if ( ! file_exists( $fonts_dir ) ) {
			wp_mkdir_p( $fonts_dir );
		}

		foreach ( $fonts as $font ) {
			if ( in_array( $font['name'], $stored_names ) ) {
				continue;
			}

			// create folder font-family if not exists.
			$font_family_dir = $fonts_dir . '/' . $font['folder'];

			if ( ! file_exists( $font_family_dir ) ) {
				wp_mkdir_p( $font_family_dir );
			}

			$font_file_path = $font_family_dir . '/' . $font['name'];

			if ( ! file_exists( $font_file_path ) ) {
				$font_file_contents = $this->get_font_file_contents( $font['src'] );

				if ( $font_file_contents ) {
					$this->filesystem->put_contents( $font_file_path, $font_file_contents );
				}
			}

			// update file path.
			$font['path'] = $font_file_path;
			$stored[] = $font;
			$change   = true;
		}

		if ( $change ) {
			update_option( 'thim_customizer_downloaded_font_files', $stored );
		}

		return $stored;
	}

	private function get_font_file_contents( $font_src ) {
		$font_src = str_replace( 'https://', 'http://', $font_src );

		$response = wp_remote_get(
			$font_src,
			array(
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$contents = wp_remote_retrieve_body( $response );

		if ( is_wp_error( $contents ) || empty( $contents ) ) {
			return false;
		}

		return $contents;
	}

	public function get_files_from_contents() {
		$contents = $this->get_content_cache();

		// get all font-family, font-weight, src.
		$pattern = '/font-family:\s*\'(.*)\';\s*font-style:\s*(.*);\s*font-weight:\s*(.*);\s*font-display:\s*(.*);\s*src:\s*url\((.*)\)\s*format\(\'(.*)\'\);\s*unicode-range:\s*(.*);/i';
		preg_match_all( $pattern, $contents, $matches );

		$fonts = array();

		if ( ! empty( $matches ) && ! empty( $matches[1] ) ) {
			foreach ( $matches[1] as $key => $font_family ) {
				$font_family = str_replace( ' ', '+', $font_family );
				$font_weight = $matches[3][ $key ];
				$font_style  = $matches[2][ $key ];
				$font_src    = $matches[5][ $key ];
				$font_format = $matches[6][ $key ];

				// font_name get file name in font_src.
				$file_name  = basename( $font_src );

				$folder_name = explode( '/', $font_src );
				$folder_name = $folder_name[4];

				$font = array(
					'name'   => $file_name,
					// 'family' => $font_family,
					'folder' => $folder_name,
					// 'weight' => $font_weight,
					// 'style'  => $font_style,
					'src'    => $font_src,
					// 'format' => $font_format,
				);

				$fonts[] = $font;
			}
		}

		return $fonts;
	}

	public function get_content_cache() {
		$cache = get_site_transient( 'thim_customizer_googlefonts_content_cache' );

		$cache_key = md5( $this->url );

		if ( ! empty( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		$contents = $this->get_google_api_contents();

		if ( $contents ) {
			$cache[ $cache_key ] = $contents;
			set_site_transient( 'thim_customizer_googlefonts_content_cache', $cache, 60 * 60 * 24 * 7 );
		}

		return $contents;
	}

	protected function get_google_api_contents() {
		$user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8';

		$response = wp_remote_get(
			$this->url,
			array(
				'timeout'    => 30,
				'user-agent' => $user_agent,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$contents = wp_remote_retrieve_body( $response );

		if ( is_wp_error( $contents ) || empty( $contents ) ) {
			return false;
		}

		return $contents;
	}

	protected function get_filesystem() {
		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once wp_normalize_path( ABSPATH . '/wp-admin/includes/file.php' );
			}
			WP_Filesystem();
		}
		return $wp_filesystem;
	}

}
