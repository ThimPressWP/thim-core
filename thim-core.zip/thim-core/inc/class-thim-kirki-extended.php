<?php

/**
 * Class Thim_Kirki_Extended.
 *
 * @since 1.7.0
 */
class Thim_Kirki_Extended extends Thim_Singleton {

    /**
     * Thim_Kirki_Extended constructor.
     *
     * @since 1.7.0
     */
    protected function __construct() {
        spl_autoload_register( array( $this, 'autoload' ) );

        $this->hooks();
    }

    /**
     * Autoload.
     *
     * @since 1.7.0
     *
     * @param $class_name
     */
    public function autoload( $class_name ) {
        switch ( $class_name ) {
            case 'Kirki_Control_Accordion':
                include_once THIM_CORE_INC_PATH . '/kirki-extended/controls/class-kirki-control-accordion.php';
                break;

            case 'Kirki_Field_Accordion':
                include_once THIM_CORE_INC_PATH . '/kirki-extended/field/class-kirki-field-accordion.php';
                break;
        }
    }

    /**
     * Register hooks.
     *
     * @since 1.7.0
     */
    private function hooks() {
        add_filter( 'kirki/control_types', array( $this, 'add_accordion_field' ) );
    }

    /**
     * Add accordion field to Kirki.
     *
     * @since 1.7.0
     *
     * @param $controls
     *
     * @return mixed
     */
    public function add_accordion_field( $controls ) {
        $controls['kirki-accordion'] = 'Kirki_Control_Accordion';

        return $controls;
    }
}