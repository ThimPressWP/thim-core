if ( undefined === window.kirki || 'undefined' === typeof window.kirki ) {
	window.kirki = {};
}
window.kirki.l10n = kirkiL10n;
