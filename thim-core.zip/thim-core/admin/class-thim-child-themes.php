<?php

/**
 * Class Thim_Child_Themes.
 *
 * @since 1.1.1
 */
class Thim_Child_Themes extends Thim_Admin_Sub_Page {

	/**
	 * @since 1.1.1
	 *
	 * @var string
	 */
	public $key_page = 'child-themes';

	/**
	 * @var Thim_Child_Theme[]
	 *
	 * @since 1.2.0
	 */
	private static $child_themes = null;

	/**
	 * Get list child themes
	 *
	 * @since 1.2.0
	 *
	 * @return Thim_Child_Theme[]
	 */
	public static function child_themes() {
		if ( self::$child_themes === null ) {
			$themes = array();

			$input_child_themes = Thim_Theme_Manager::get_data( 'child_themes' );
			if ( empty( $input_child_themes ) || ! is_array( $input_child_themes ) ) {
				self::$child_themes = array();

				return self::$child_themes;
			}

			foreach ( $input_child_themes as $args ) {
				$themes[] = new Thim_Child_Theme( $args );
			}

			self::$child_themes = $themes;
		}

		return self::$child_themes;
	}

	/**
	 * Get data list child themes.
	 *
	 * @since 1.2.0
	 *
	 * @return array
	 */
	public static function get_data_child_themes() {
		$child_themes = self::child_themes();
		$themes       = array_map(
			function ( $theme ) {
				$data = $theme->toArray();

				unset( $data['source'] );

				return $data;
			},
			$child_themes
		);

		return $themes;
	}

	/**
	 * Thim_Child_Themes constructor.
	 *
	 * @since 1.1.1
	 */
	protected function __construct() {
		parent::__construct();

		$this->init_hooks();
	}

	/**
	 * Init hooks.
	 *
	 * @since 1.1.1
	 */
	private function init_hooks() {
		add_filter( 'thim_dashboard_sub_pages', array( $this, 'add_sub_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'switch_theme', array( $this, 'switch_theme_update_mods' ) );
		add_action( 'wp_ajax_thim_child_themes_action', array( $this, 'handle_ajax_action' ) );
	}

	/**
	 * Handle ajax action.
	 *
	 * @since 1.2.0
	 */
	public function handle_ajax_action() {
		$slug   = isset( $_REQUEST['slug'] ) ? $_REQUEST['slug'] : false;
		$action = isset( $_REQUEST['thim_action'] ) ? $_REQUEST['thim_action'] : false;

		if ( empty( $slug ) || empty( $action ) ) {
			wp_send_json_error( __( 'Something went wrong!', 'thim-core' ) );
		}

		$result = new WP_Error( 'thim_core_them_not_found', __( 'This theme not exist!', 'thim-core' ) );

		$themes = self::child_themes();
		foreach ( $themes as $theme ) {
			$theme_slug   = $theme->get( 'slug' );
			$theme_status = $theme->get_status();

			if ( $slug == $theme_slug ) {
				switch ( $action ) {
					case 'install':
						if ( $theme_status != 'not_installed' ) {
							wp_send_json_error( __( 'This theme has already installed!', 'thim-core' ) );
						}

						$result = $theme->install();

						break;

					case 'activate':
						if ( $theme_status == 'not_installed' ) {
							wp_send_json_error( __( 'This theme has not installed yet!', 'thim-core' ) );
						}
						$result = $theme->activate();

						break;
				}
			}
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		Thim_Theme_Manager::flush();
		$themes = self::get_data_child_themes();

		wp_send_json_success( $themes );
	}

	/**
	 * Update theme mods when switch theme.
	 *
	 * @since 1.0.3
	 */
	public function switch_theme_update_mods() {
		if ( ! thim_core_is_child_theme() ) {
			return;
		}

		$child_mods = get_theme_mods();
		if ( ! empty( $child_mods ) ) {
			//return;
		}

		if ( get_theme_mod( 'thim_core_extend_parent_theme', false ) ) {
			return;
		}

		$mods = get_option( 'theme_mods_' . get_option( 'template' ) );

		if ( false === $mods ) {
			return;
		}

		foreach ( (array) $mods as $mod => $value ) {
			set_theme_mod( $mod, $value );
		}

		set_theme_mod( 'thim_core_extend_parent_theme', true );
	}

	/**
	 * Add sub page.
	 *
	 * @since 1.1.1
	 *
	 * @param $sub_pages array
	 *
	 * @return array
	 */
	public function add_sub_page( $sub_pages ) {
		if ( ! current_user_can( 'switch_themes' ) && ! current_user_can( 'edit_theme_options' ) ) {
			return $sub_pages;
		}

		$theme_data   = Thim_Theme_Manager::get_metadata();
		$child_themes = $theme_data['child_themes'];

		if ( empty( $child_themes ) ) {
			return $sub_pages;
		}

		$sub_pages[ $this->key_page ] = array(
			'title' => __( 'Child Themes', 'thim-core' ),
			'icon' => '<svg width="26" height="25" viewBox="0 0 26 25" fill="none" xmlns="http://www.w3.org/2000/svg">
							<g clip-path="url(#clip0_289_329)">
								<path d="M11.1771 11.7188H1.28125C0.849998 11.7188 0.5 11.3688 0.5 10.9375C0.5 10.5062 0.849998 10.1562 1.28125 10.1562H11.1771C11.6084 10.1562 11.9584 10.5062 11.9584 10.9375C11.9584 11.3688 11.6084 11.7188 11.1771 11.7188Z" fill="#444444"/>
								<path d="M7.27081 15.625C7.07072 15.625 6.87083 15.5489 6.71863 15.3959C6.41345 15.0906 6.41345 14.5958 6.71863 14.2906L10.0729 10.9365L6.71863 7.58343C6.41345 7.27806 6.41345 6.78329 6.71863 6.47812C7.0238 6.17294 7.51857 6.17294 7.82394 6.47812L11.7302 10.3844C12.0354 10.6895 12.0354 11.1843 11.7302 11.4897L7.82394 15.3959C7.67078 15.5489 7.4707 15.625 7.27081 15.625Z" fill="#444444"/>
								<path d="M17.1667 25C16.0177 25 15.0835 24.0656 15.0835 22.9166V4.1666C15.0835 3.27606 15.6502 2.48127 16.4938 2.18849L22.7522 0.10204C24.1522 -0.327113 25.5001 0.711438 25.5001 2.08339V20.8334C25.5001 21.723 24.9334 22.5166 24.0908 22.8104L17.8303 24.898C17.6021 24.9687 17.3908 25 17.1667 25ZM23.4167 1.5625C23.349 1.5625 23.2918 1.57089 23.2304 1.58958L16.9981 3.66764C16.7938 3.73859 16.646 3.94478 16.646 4.1666V22.9166C16.646 23.2719 17.0313 23.5115 17.3532 23.4104L23.5855 21.3324C23.7886 21.2614 23.9376 21.0552 23.9376 20.8334V2.08339C23.9376 1.79691 23.7043 1.5625 23.4167 1.5625Z" fill="#444444"/>
								<path d="M9.61475 5.2084C9.18349 5.2084 8.8335 4.8584 8.8335 4.42715V2.86465C8.8335 1.28441 10.1177 0 11.698 0H23.4167C23.848 0 24.198 0.349998 24.198 0.78125C24.198 1.2125 23.848 1.5625 23.4167 1.5625H11.698C10.9802 1.5625 10.396 2.14691 10.396 2.86465V4.42715C10.396 4.8584 10.046 5.2084 9.61475 5.2084Z" fill="#444444"/>
								<path d="M15.8647 21.875H11.698C10.1177 21.875 8.8335 20.5906 8.8335 19.0103V17.4478C8.8335 17.0166 9.18349 16.6666 9.61475 16.6666C10.046 16.6666 10.396 17.0166 10.396 17.4478V19.0103C10.396 19.7281 10.9802 20.3125 11.698 20.3125H15.8647C16.296 20.3125 16.646 20.6625 16.646 21.0937C16.646 21.525 16.296 21.875 15.8647 21.875Z" fill="#444444"/>
							</g>
								<defs><clipPath id="clip0_289_329"><rect width="25" height="25" fill="white" transform="translate(0.5)"/></clipPath></defs>
						</svg>',
		);

		return $sub_pages;
	}

	/**
	 * Enqueue scripts.
	 *
	 * @since 1.2.0
	 */
	public function enqueue_scripts() {
		if ( ! $this->is_myself() ) {
			return;
		}

		wp_enqueue_script( 'thim-child-themes', THIM_CORE_ADMIN_URI . '/assets/js/child-themes.js', array( 'wp-util', 'jquery', 'backbone', 'underscore' ), THIM_CORE_VERSION );
		$this->localize_script();
	}

	/**
	 * Localize script.
	 *
	 * @since 1.2.0
	 */
	private function localize_script() {
		$data = $this->get_data_template();
		wp_localize_script( 'thim-child-themes', 'tc_child_themes', $data );
	}

	/**
	 * Get data template.
	 *
	 * @since 1.2.0
	 *
	 * @return array
	 */
	private function get_data_template() {
		$themes = self::get_data_child_themes();

		return array(
			'themes'      => $themes,
			'url_ajax'    => admin_url( 'admin-ajax.php' ),
			'ajax_action' => 'thim_child_themes_action'
		);
	}
}
