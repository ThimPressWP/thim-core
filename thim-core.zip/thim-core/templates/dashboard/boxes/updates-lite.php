<?php

do_action( 'thim_core_background_check_update_theme_lite' );

$theme_data      = Thim_Theme_Manager::get_metadata();
$template        = $theme_data['template'];
$current_version = $theme_data['version'];

$update_themes = Thim_Free_Theme::get_update_themes();
$themes        = $update_themes['themes'];

$data = isset( $themes[$template] ) ? $themes[$template] : false;

$purchase_code = Thim_Product_Registration::get_data_theme_register( 'purchase_code' );

$link_check = Thim_Dashboard::get_link_main_dashboard(
	array(
		'force-check' => 1,
	)
);

$can_update = version_compare( $data['version'], $current_version, '>' );
?>

<div class="tc-box-body">
	<div class="td-box-welcome-admin">
		<div class="box-left">
			<p>
				<?php printf(
					__(
						'Thanks for installing the %1$s theme. If this is the first time you work with %1$s, please read and follow
			the instructions carefully. This is the getting started section of %1$s Theme Dashboard.', 'thim-core'
					), $data['name']
				); ?>
			</p>
			<a href="<?php echo admin_url( 'admin.php?page=thim-getting-started' ); ?>"
			   class="tc-button-box tc-button-black"><?php esc_html_e( 'Let\'s get started', 'thim-core' ); ?></a>
		</div>
		<div class="box-right">
			<?php
			if ( ! $data ) {
				$data_info = array(
					'title'      => __( 'Something went wrong!', 'thim-core' ),
					'desc'       => __( 'Please try again later.', 'thim-core' ),
					'class'      => 'no-info-theme',
					'btn-update' => '',
				);
			} else {
				if ( $can_update ) {
					$data_info = array(
						'title' => __( 'New version available', 'thim-core' ),
						'class' => 'has-update',
						'desc'  => __( 'Your Version is', 'thim-core' ) . ' ' . $current_version
					);
					if ( empty( $purchase_code ) ) {
						$data_info['btn-update'] = '<div class="update-notice"><a href="' . esc_url( add_query_arg( array( 'page' => 'thim-license', 'thim_redirect' => urlencode( $link_check ) ), admin_url( 'admin.php' ) ) ) . '" class="button-link">' . __( 'Activate now.', 'thim-core' ) . '</a></div>';
					} else {
						$data_info['btn-update'] = '<div class="update-message"><button class="button-link tc-update-now" type="button">' . esc_html__( 'Update now', 'thim-core' ) . '</button></div>';
					}
				} else {
					$data_info = array(
						'title'      => __( 'Theme is up to date', 'thim-core' ),
						'class'      => 'no-update',
						'desc'       => __( 'Your Version is', 'thim-core' ) . ' ' . $current_version,
						'btn-update' => '',
					);
				}
			}

			$requirements_notification = apply_filters( 'thim_core_number_requirements_notification', 0 );
			if ( $requirements_notification > 0 ) {
				$requiremen_info = array(
					'title' => __( 'Something wrong', 'thim-core' ),
					'desc'  => __( 'We detected ' . $requirements_notification . ' issues', 'thim-core' ),
					'link'  => admin_url( 'admin.php?page=thim-system-status' ),
					'icon'  => '',
				);
			} else {
				$requiremen_info = array(
					'title' => __( 'All is Good', 'thim-core' ),
					'desc'  => __( 'Nothing wrong found', 'thim-core' ),
					'icon'  => ' icon-success',
				);
			}
			?>
			<div class="box box-info-update <?php echo esc_attr( $data_info['class'] ); ?>">
				<span class="icon"></span>
				<h5><?php echo $data_info['title']; ?></h5>
				<p><?php echo $data_info['desc']; ?></p>
				<?php echo $data_info['btn-update']; ?>
			</div>
			<div class="box box-info-reqirements<?php echo $requiremen_info['icon']; ?>">
				<span class="icon">
					<svg width="35" height="35" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path
							d="M11.13 23.3275C10.7773 23.6237 10.5556 24.0471 10.513 24.5058C10.4704 24.9644 10.6104 25.4214 10.9025 25.7775C11.0494 25.9547 11.2298 26.1012 11.4334 26.2085C11.6371 26.3159 11.8598 26.3821 12.0891 26.4032C12.3183 26.4243 12.5494 26.4 12.7692 26.3317C12.989 26.2634 13.1932 26.1523 13.37 26.005C14.5398 25.0618 15.9973 24.5474 17.5 24.5474C19.0027 24.5474 20.4602 25.0618 21.63 26.005C21.9448 26.2659 22.3411 26.4083 22.75 26.4075C23.1063 26.404 23.453 26.2918 23.7438 26.086C24.0346 25.8801 24.2556 25.5905 24.3774 25.2556C24.4991 24.9208 24.5158 24.5568 24.4251 24.2122C24.3345 23.8677 24.1408 23.559 23.87 23.3275C22.0642 21.876 19.8169 21.0847 17.5 21.0847C15.1832 21.0847 12.9358 21.876 11.13 23.3275ZM12.6175 14.945C12.9454 15.2709 13.3889 15.4539 13.8513 15.4539C14.3136 15.4539 14.7571 15.2709 15.085 14.945C15.4109 14.6171 15.5939 14.1736 15.5939 13.7112C15.5939 13.2489 15.4109 12.8054 15.085 12.4775C14.0835 11.5272 12.7556 10.9975 11.375 10.9975C9.99443 10.9975 8.66649 11.5272 7.66501 12.4775C7.48181 12.6344 7.33303 12.8274 7.22799 13.0445C7.12295 13.2617 7.06392 13.4981 7.05461 13.7392C7.0453 13.9802 7.08591 14.2205 7.17389 14.4451C7.26187 14.6696 7.39532 14.8736 7.56587 15.0441C7.73641 15.2147 7.94037 15.3481 8.16494 15.4361C8.38951 15.5241 8.62984 15.5647 8.87085 15.5554C9.11186 15.5461 9.34834 15.4871 9.56545 15.382C9.78257 15.277 9.97562 15.1282 10.1325 14.945C10.2952 14.781 10.4887 14.6508 10.702 14.5619C10.9152 14.4731 11.144 14.4274 11.375 14.4274C11.606 14.4274 11.8348 14.4731 12.048 14.5619C12.2613 14.6508 12.4548 14.781 12.6175 14.945ZM17.5 0C14.0388 0 10.6554 1.02636 7.77753 2.94928C4.89967 4.87221 2.65665 7.60533 1.33212 10.803C0.00758247 14.0007 -0.338976 17.5194 0.336265 20.9141C1.01151 24.3087 2.67822 27.4269 5.12564 29.8744C7.57306 32.3218 10.6913 33.9885 14.0859 34.6637C17.4806 35.339 20.9993 34.9924 24.197 33.6679C27.3947 32.3434 30.1278 30.1003 32.0507 27.2225C33.9736 24.3446 35 20.9612 35 17.5C35 15.2019 34.5474 12.9262 33.6679 10.803C32.7884 8.67984 31.4994 6.75066 29.8744 5.12563C28.2493 3.50061 26.3202 2.21157 24.197 1.33211C22.0738 0.452651 19.7981 0 17.5 0ZM17.5 31.5C14.7311 31.5 12.0243 30.6789 9.72202 29.1406C7.41973 27.6022 5.62532 25.4157 4.56569 22.8576C3.50607 20.2994 3.22882 17.4845 3.76901 14.7687C4.30921 12.053 5.64258 9.55844 7.60051 7.6005C9.55845 5.64257 12.053 4.3092 14.7687 3.76901C17.4845 3.22881 20.2994 3.50606 22.8576 4.56569C25.4157 5.62531 27.6022 7.41973 29.1406 9.72201C30.6789 12.0243 31.5 14.7311 31.5 17.5C31.5 21.213 30.025 24.774 27.3995 27.3995C24.774 30.025 21.213 31.5 17.5 31.5ZM27.335 12.4775C26.3335 11.5272 25.0056 10.9975 23.625 10.9975C22.2444 10.9975 20.9165 11.5272 19.915 12.4775C19.6283 12.8123 19.4785 13.2429 19.4955 13.6833C19.5125 14.1238 19.6951 14.5416 20.0068 14.8532C20.3184 15.1649 20.7362 15.3475 21.1767 15.3645C21.6171 15.3815 22.0477 15.2317 22.3825 14.945C22.5452 14.781 22.7387 14.6508 22.952 14.5619C23.1652 14.4731 23.394 14.4274 23.625 14.4274C23.856 14.4274 24.0848 14.4731 24.298 14.5619C24.5113 14.6508 24.7048 14.781 24.8675 14.945C25.1954 15.2709 25.6389 15.4539 26.1013 15.4539C26.5636 15.4539 27.0071 15.2709 27.335 14.945C27.6609 14.6171 27.8439 14.1736 27.8439 13.7112C27.8439 13.2489 27.6609 12.8054 27.335 12.4775Z"
							fill="#F24E1E"/>
					</svg>
				</span>
				<h5><?php echo $requiremen_info['title']; ?></h5>
				<p><?php echo $requiremen_info['desc']; ?></p>
				<?php
				if ( isset( $requiremen_info['link'] ) ) {
					echo '<div class="update-notice"><a href="' . $requiremen_info['link'] . '">Resolve now</a></div>';
				}
				?>
			</div>
		</div>
	</div>
</div>
