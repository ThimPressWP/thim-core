<div class="tc-box-body">
<p>We hope that this theme will help you create a professional and effective educational website. If you are happy with our theme, please consider rating 5 stars for our theme. We would highly appreciate that.</p>
<a href="<?php echo esc_url(Thim_Product_Registration::get_link_reviews());?>" target="_blank" class="tc-button-box tc-button-black">Let's get started</a>
</div>
