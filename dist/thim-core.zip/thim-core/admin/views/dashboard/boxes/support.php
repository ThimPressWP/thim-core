<div class="tc-box-body">
    <div class="text-center">
        <p>No data</p>
    </div>
</div>