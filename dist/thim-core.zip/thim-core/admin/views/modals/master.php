<div class="tc-modal md-modal md-effect-16" id="<?php echo esc_attr( $args['id'] ) ?>" data-template="<?php echo esc_attr( $args['id'] ) ?>">
</div>
<div class="md-overlay"></div>

<script type="text/html" id="tmpl-<?php echo esc_attr( $args['id'] ) ?>">
	<div class="md-content">
		<?php echo $args['html']; ?>
	</div>
</script>
